#include <stdio.h>

int main()
{
    int n;
    float a, d;

    printf("please enter first element of series(a): ");
    scanf("%f",&a);
    printf("\n");


    printf("please enter step size of series(d): ");
    scanf("%f",&d);
    printf("\n");


    printf("please enter number of element(n): ");
    scanf("%d",&n);
    printf("\n");


    /*
    int ai;
    int S;
    int i=0;
    while (i<n);
    {
        ai=ai*d;
        S+=ai;
        printf("%d\t%f\t\f\t\n",i,ai,S);
        i++;
    }
    */
    int i;
    int ai;
    int S;
    for(i=0;i<n;i++)
    {
        ai=ai*d;
        S+=ai;
        printf("%d\t%f\t\f\t\n",i,ai,S);
    }
    printf("\n\nfinal sum of series(S)= %f\n",S);

    return 0;
}
