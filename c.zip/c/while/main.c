#include <stdio.h>

int main()
{
    int n=10;
    int a, S, i;
        i=0;
        S=0;

        while(i<n)
        {
            printf("enter a number: ");
            scanf("%d",&a);
            if(a==-1) break;

            S+=a;
            i++;
        }
        printf("\nsum of numbers: %d\n\n",S);
        float m=(float)S/i;
        printf("mean of numbers: %.2f\n\n",m);

    return 0;
}
