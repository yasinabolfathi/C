#include <stdio.h>

int main()
{
    int a, b, c;

    printf("please enter an integer:\n");
    scanf("%d", &a);

    printf("please enter another integer:\n");
    scanf("%d", &b);

    c = a + b;
    printf("%d + %d = %d\n",a,b,c);

    int d;
    d = a * d;
    printf("%d * %d = %d\n",a,b,d);

    printf("%d mod %d = %d\n",a,b,a%b);

    return 0;
}
