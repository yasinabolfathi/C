#include <stdio.h>

int main()
{
    printf("Hello\"world\"!\n\n\a");
    printf("yasin\tyasan\tapple\n");

    return 0;
}
