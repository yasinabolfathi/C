#include <stdio.h>

int main()
{

    int a;
    printf("enter an integer:\n");
    scanf("%d",&a);

    if("a%2==0")
    {
        printf("%d is EVEN.\n",a);
        printf("\a");
    }
    else
   {
       printf("%d is ODD\n",a);
   }
   if (a>0)
   {
       printf("%d is possitive.\n",a);
   }
   else if (a<0)
   {
       printf("%d is negative.");
   }
   else
   {

       printf("%d is zero");
   }
    return 0;
}
