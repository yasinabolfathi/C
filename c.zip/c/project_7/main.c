#include <stdio.h>
#define TRUE -1

int main()
{
    char g;
    while(TRUE)
    {
        g = getchar ();
        if (g==EOF) break;
    }

    return 0;
}
